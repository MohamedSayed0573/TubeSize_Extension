console.log("[background] Service worker starting");

import { filesize } from "filesize";
import type { Data, StorageData, HumanizedFormat, RawFormat } from "./types";
import ms from "ms";

async function saveToStorage(
    tag: string,
    response: Data | HumanizedFormat | null,
) {
    if (!response) return;
    response.createdAt = new Date().toISOString();

    const ttlInSeconds = 60 * 60 * 24 * 7;
    const expiry = Date.now() + ttlInSeconds * 1000;

    const dataToStore = {
        response,
        expiry,
    };

    await chrome.storage.local.set({ [tag]: dataToStore });
}

async function getFromStorage(tag: string) {
    const data = await chrome.storage.local.get(tag);
    const item = data[tag] as StorageData | undefined;

    if (!item) return null;

    // Tag expired
    if (item.expiry && item.expiry < Date.now()) {
        await chrome.storage.local.remove(tag);
        return null;
    }

    return item.response;
}

function addBadge(tabId: number | undefined) {
    if (!tabId) return;
    chrome.action.setBadgeText({ tabId: tabId, text: "✓" });
    chrome.action.setBadgeBackgroundColor({
        tabId: tabId,
        color: "#28a745",
    });
}

function clearBadge(tabId: number | undefined) {
    if (!tabId) return;
    chrome.action.setBadgeText({ tabId, text: "" });
}

chrome.runtime.onMessage.addListener(
    (
        message: { type: string; value: string; tabId: number },
        sender,
        sendResponse,
    ) => {
        if (message.type === "clearBadge") {
            clearBadge(sender.tab?.id);
            return;
        }

        if (message.type !== "sendYoutubeUrl") {
            return;
        }

        const tag = message.value;

        // sender will have a tab property if the message is from content script
        // If the message is from popup, sender.tab will be undefined. But sender.url will be valid.
        const tabId = sender.tab?.id ?? message.tabId;
        console.log(
            `[background] Received tag: ${tag} From ${sender.tab?.id ? "Content.js" : "Popup.js"}`,
        );

        // Clear the badge on each request
        clearBadge(tabId);

        (async () => {
            const cached = await getFromStorage(tag);

            // Cache Hit
            if (cached) {
                console.log("[background] Using cached data:", cached);

                // Set the badge to green checkmark
                addBadge(tabId);
                sendResponse({ success: true, data: cached, cached: true });
                return;
            }

            // Cache Miss
            try {
                try {
                    const data = await fetchVideoData(tag);
                    const formattedData = await formatVideoResponse(data);
                    saveToStorage(tag, formattedData);
                    addBadge(tabId);
                    sendResponse({
                        success: true,
                        data: formattedData,
                        cached: false,
                    });
                    return;
                } catch (err) {
                    const apiData = await fetchAPI(tag, tabId);
                    saveToStorage(tag, apiData);
                    addBadge(tabId);
                    sendResponse({ succes: true, apiData, cached: false });
                    return;
                }
            } catch (err) {
                clearBadge(tabId);
                sendResponse({ success: false, data: null, cached: false });
                return;
            }
        })();

        return true; // Return true synchronously to keep the message channel open
    },
);

const VIDEO_ITAGS = [394, 395, 396, 397, 398, 399];

async function fetchVideoData(videoTag: string) {
    let res;
    try {
        res = await fetch(`https://www.youtube.com/watch?v=${videoTag}`);
    } catch (err) {
        console.error(err);
        return null;
    }
    const htmlText = await res.text();
    const match = htmlText.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\});/);
    //console.log(match[1]);
    if (!match || !match[1]) return null;

    try {
        const data = JSON.parse(match[1]);
        if (!data) return null;
        return data;
    } catch (e) {
        console.error("Failed to parse JSON", e);
        return null;
    }
}
async function formatVideoResponse(data: any) {
    if (!data) return null;

    const result: RawFormat = {
        id: data.videoDetails.videoTag,
        title: data.videoDetails.title,
        author: data.videoDetails.author,
        duration: data.streamingData.adaptiveFormats[0].approxDurationMs,
        formats: data.streamingData.adaptiveFormats
            .filter((format: any) => {
                return VIDEO_ITAGS.includes(format.itag);
            })
            .map((format: any) => {
                return {
                    formatId: format.itag,
                    height: format.height,
                    mimeType: format.mimeType,
                    size: parseInt(format.contentLength || 0),
                };
            }),
        audioFormats: data.streamingData.adaptiveFormats
            .filter((format: any) => {
                return format.itag === 251;
            })
            .map((format: any) => {
                return {
                    formatId: format.itag,
                    mimeType: format.mimeType,
                    size: parseInt(format.contentLength || 0),
                };
            }),
    };
    const audioSize = getAverageAudioSize(result.audioFormats);
    const formats = mergeAudioWithVideo(result.formats, audioSize);
    const humanizedFormats = humanizeVideoFormats(formats);

    const final: HumanizedFormat = {
        id: result.id,
        title: result.title,
        author: result.author,
        duration: ms(parseInt(result.duration)),
        videoFormats: humanizedFormats,
    };
    // console.log(humanizedData);
    return final;
}

function humanizeVideoFormats(formats: RawFormat["formats"]) {
    return formats.map((format) => {
        return {
            ...format,
            size: filesize(format.size),
        };
    });
}

function getAverageAudioSize(audioFormatArray: RawFormat["audioFormats"]) {
    if (audioFormatArray.length === 0) return 0;
    if (audioFormatArray.length === 1) return audioFormatArray[0].size;
    return (
        audioFormatArray.reduce((acc, format) => {
            return acc + format.size;
        }, 0) / audioFormatArray.length
    );
}
function mergeAudioWithVideo(
    videoFormats: RawFormat["formats"],
    audioSize: number,
) {
    return videoFormats.map((videoFormat) => {
        return {
            ...videoFormat,
            size: (videoFormat.size as number) + audioSize,
        };
    });
}

async function fetchAPI(tag: string, tabId: number) {
    const humanReadableSizes = true;
    const mergeAudioWithVideo = true;
    const apiUrl = `${__API_URL__}/api/video-sizes/${tag}/?humanReadableSizes=${humanReadableSizes}&mergeAudioWithVideo=${mergeAudioWithVideo}`;
    console.log("[background] Fetching URL:", apiUrl);

    const res = await fetch(apiUrl, {
        method: "GET",
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = (await res.json()) as Data;
    console.log("[background] Got data:", data);
    return data;
}
